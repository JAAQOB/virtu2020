<?php
/**
 * Template Name: Home Page Template
 */
get_header();
?>

<?php get_template_part('templates/homepage/top-slider'); ?>
<?php get_template_part('templates/homepage/secret'); ?>

<?php get_template_part('templates/homepage/news-homepage'); ?>
<?php get_template_part('templates/homepage/where-buy-homepage'); ?>

<?php get_footer(); ?>
